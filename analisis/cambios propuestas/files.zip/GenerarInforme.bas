Attribute VB_Name = "GenerarInforme"
' ============================================================
' MÓDULO 1 — GENERADOR AUTOMÁTICO DE INFORME MENSUAL
' Versión 1.0 — Marzo 2026
' Instrucciones de instalación al final del archivo
' ============================================================

Option Explicit

' ── CONFIGURACIÓN GLOBAL ──────────────────────────────────
Const NOMBRE_TIENDA As String = ""   ' Ej: "APATZINGÁN" — déjalo vacío para que lo tome automático
Const COLOR_AZUL As Long = RGB(27, 58, 107)
Const COLOR_AZUL_CLARO As Long = RGB(214, 228, 240)
Const COLOR_VERDE As Long = RGB(26, 107, 58)
Const COLOR_ROJO As Long = RGB(180, 0, 0)
Const COLOR_GRIS As Long = RGB(245, 245, 245)

' ─────────────────────────────────────────────────────────
' PUNTO DE ENTRADA: botón "Generar Informe"
' ─────────────────────────────────────────────────────────
Sub GenerarInformeMensual()
    Dim wb As Workbook
    Dim wsCorte As Worksheet
    Dim wsDias As Worksheet
    Dim wsResumen As Worksheet
    Dim wsGrafica As Worksheet
    
    wb = ActiveWorkbook
    
    ' ── Detectar hojas automáticamente ──
    Dim sheetName As String
    sheetName = ""
    Dim ws As Worksheet
    For Each ws In wb.Worksheets
        Dim n As String
        n = UCase(ws.Name)
        If InStr(n, "CAJA") > 0 Or InStr(n, "ENERO") > 0 Or InStr(n, "FEBRERO") > 0 Or _
           InStr(n, "MARZO") > 0 Or InStr(n, "ABRIL") > 0 Or InStr(n, "MAYO") > 0 Or _
           InStr(n, "JUNIO") > 0 Or InStr(n, "JULIO") > 0 Or InStr(n, "AGOSTO") > 0 Or _
           InStr(n, "SEPTIEMBRE") > 0 Or InStr(n, "OCTUBRE") > 0 Or _
           InStr(n, "NOVIEMBRE") > 0 Or InStr(n, "DICIEMBRE") > 0 Then
            If InStr(n, "DIA") = 0 And InStr(n, "RESUMEN") = 0 And InStr(n, "GRAFICA") = 0 Then
                sheetName = ws.Name
            End If
        End If
    Next ws
    
    If sheetName = "" Then
        ' Si no se encontró, usar la primera hoja
        sheetName = wb.Worksheets(1).Name
    End If
    
    wsCorte = wb.Worksheets(sheetName)
    
    ' Buscar hoja de días de la semana
    Dim wsDiasName As String
    wsDiasName = ""
    For Each ws In wb.Worksheets
        If InStr(UCase(ws.Name), "DIA") > 0 Then
            wsDiasName = ws.Name
        End If
    Next ws
    
    ' Buscar hoja de resumen
    Dim wsResumenName As String
    wsResumenName = ""
    For Each ws In wb.Worksheets
        If InStr(UCase(ws.Name), "RESUMEN") > 0 Then
            wsResumenName = ws.Name
        End If
    Next ws
    
    ' Buscar hoja de gráfica
    Dim wsGraficaName As String
    wsGraficaName = ""
    For Each ws In wb.Worksheets
        If InStr(UCase(ws.Name), "GRAFICA") > 0 Then
            wsGraficaName = ws.Name
        End If
    Next ws
    
    ' ── Leer datos del corte de caja ──
    Dim datos As New Collection
    Dim ultimaFila As Long
    ultimaFila = wsCorte.Cells(wsCorte.Rows.Count, 1).End(xlUp).Row
    
    Dim i As Long
    Dim totalIngresos As Double
    Dim totalEgresos As Double
    Dim totalVentas As Double
    Dim totalCobranza As Double
    Dim totalDeclarado As Double
    Dim totalDiferencia As Double
    Dim totalCredito As Double
    
    totalIngresos = 0
    totalEgresos = 0
    totalVentas = 0
    totalCobranza = 0
    totalDeclarado = 0
    totalDiferencia = 0
    totalCredito = 0
    
    ' Buscar la fila de totales (la última con datos)
    For i = 2 To ultimaFila
        If Not IsEmpty(wsCorte.Cells(i, 1)) And IsDate(wsCorte.Cells(i, 1)) Then
            Dim ventas As Double
            Dim cob As Double
            Dim ing As Double
            Dim egr As Double
            Dim tot As Double
            Dim cred As Double
            Dim decl As Double
            Dim dif As Double
            
            ventas = LimpiarNumero(wsCorte.Cells(i, 5))
            cob = LimpiarNumero(wsCorte.Cells(i, 6))
            ing = LimpiarNumero(wsCorte.Cells(i, 7))
            egr = LimpiarNumero(wsCorte.Cells(i, 8))
            tot = LimpiarNumero(wsCorte.Cells(i, 9))
            cred = LimpiarNumero(wsCorte.Cells(i, 10))
            decl = LimpiarNumero(wsCorte.Cells(i, 11))
            dif = LimpiarNumero(wsCorte.Cells(i, 13))
            
            totalVentas = totalVentas + ventas
            totalCobranza = totalCobranza + cob
            totalIngresos = totalIngresos + ing
            totalEgresos = totalEgresos + egr
            totalDeclarado = totalDeclarado + decl
            totalDiferencia = totalDiferencia + dif
            totalCredito = totalCredito + cred
        End If
    Next i
    
    ' ── Detectar mes y tienda del nombre del libro ──
    Dim nombreLibro As String
    nombreLibro = UCase(wb.Name)
    
    Dim mesNombre As String
    mesNombre = DetectarMes(nombreLibro)
    
    Dim tiendaNombre As String
    If NOMBRE_TIENDA <> "" Then
        tiendaNombre = NOMBRE_TIENDA
    Else
        tiendaNombre = DetectarTienda(nombreLibro)
    End If
    
    ' ── Leer totales por día de semana ──
    Dim diasSemana(5, 3) As String  ' [dia, ingresos, declarado, diferencia]
    Dim diasNombres(5) As String
    diasNombres(0) = "LUNES"
    diasNombres(1) = "MARTES"
    diasNombres(2) = "MIERCOLES"
    diasNombres(3) = "JUEVES"
    diasNombres(4) = "VIERNES"
    diasNombres(5) = "SABADO"
    
    Dim ingLunes As Double, ingMartes As Double, ingMierc As Double
    Dim ingJueves As Double, ingViernes As Double, ingSabado As Double
    Dim declLunes As Double, declMartes As Double, declMierc As Double
    Dim declJueves As Double, declViernes As Double, declSabado As Double
    Dim difLunes As Double, difMartes As Double, difMierc As Double
    Dim difJueves As Double, difViernes As Double, difSabado As Double
    
    ' Leer desde hoja de días si existe
    If wsDiasName <> "" Then
        Dim wsDiasTemp As Worksheet
        wsDiasTemp = wb.Worksheets(wsDiasName)
        Dim ultimaDias As Long
        ultimaDias = wsDiasTemp.Cells(wsDiasTemp.Rows.Count, 1).End(xlUp).Row
        
        Dim j As Long
        For j = ultimaDias - 10 To ultimaDias
            If j < 1 Then j = 1
            Dim celTxt As String
            celTxt = UCase(Trim(CStr(wsDiasTemp.Cells(j, 2).Value)))
            
            Select Case celTxt
                Case "VENTAS DEL LUNES", "LUNES"
                    If Not IsEmpty(wsDiasTemp.Cells(j, 4)) Then
                        ingLunes = LimpiarNumero(wsDiasTemp.Cells(j, 4))
                        declLunes = LimpiarNumero(wsDiasTemp.Cells(j, 7))
                        difLunes = LimpiarNumero(wsDiasTemp.Cells(j, 8))
                    End If
                Case "VENTAS DEL MARTES", "MARTES"
                    If Not IsEmpty(wsDiasTemp.Cells(j, 4)) Then
                        ingMartes = LimpiarNumero(wsDiasTemp.Cells(j, 4))
                        declMartes = LimpiarNumero(wsDiasTemp.Cells(j, 7))
                        difMartes = LimpiarNumero(wsDiasTemp.Cells(j, 8))
                    End If
                Case "VENTAS DEL MIERCOLES", "MIERCOLES"
                    If Not IsEmpty(wsDiasTemp.Cells(j, 4)) Then
                        ingMierc = LimpiarNumero(wsDiasTemp.Cells(j, 4))
                        declMierc = LimpiarNumero(wsDiasTemp.Cells(j, 7))
                        difMierc = LimpiarNumero(wsDiasTemp.Cells(j, 8))
                    End If
                Case "VENTAS DEL JUEVES", "JUEVES"
                    If Not IsEmpty(wsDiasTemp.Cells(j, 4)) Then
                        ingJueves = LimpiarNumero(wsDiasTemp.Cells(j, 4))
                        declJueves = LimpiarNumero(wsDiasTemp.Cells(j, 7))
                        difJueves = LimpiarNumero(wsDiasTemp.Cells(j, 8))
                    End If
                Case "VENTAS DEL VIERNES", "VIERNES"
                    If Not IsEmpty(wsDiasTemp.Cells(j, 4)) Then
                        ingViernes = LimpiarNumero(wsDiasTemp.Cells(j, 4))
                        declViernes = LimpiarNumero(wsDiasTemp.Cells(j, 7))
                        difViernes = LimpiarNumero(wsDiasTemp.Cells(j, 8))
                    End If
                Case "VENTAS DEL SABADO", "SABADO"
                    If Not IsEmpty(wsDiasTemp.Cells(j, 4)) Then
                        ingSabado = LimpiarNumero(wsDiasTemp.Cells(j, 4))
                        declSabado = LimpiarNumero(wsDiasTemp.Cells(j, 7))
                        difSabado = LimpiarNumero(wsDiasTemp.Cells(j, 8))
                    End If
            End Select
        Next j
    End If
    
    ' ── Leer datos de gráfica (venta máxima/mínima/promedio) ──
    Dim ventaMax As Double, ventaMin As Double, ventaProm As Double
    If wsGraficaName <> "" Then
        Dim wsGrafTemp As Worksheet
        wsGrafTemp = wb.Worksheets(wsGraficaName)
        Dim gFila As Long
        Dim gMax As Long
        gMax = wsGrafTemp.Cells(wsGrafTemp.Rows.Count, 1).End(xlUp).Row
        For gFila = 1 To gMax
            Dim gTxt As String
            gTxt = UCase(Trim(CStr(wsGrafTemp.Cells(gFila, 1).Value)))
            If InStr(gTxt, "PROMEDIO") > 0 Then
                ventaProm = LimpiarNumero(wsGrafTemp.Cells(gFila, 2))
            ElseIf InStr(gTxt, "MAXIMA") > 0 Or InStr(gTxt, "MÁXIMA") > 0 Then
                ventaMax = LimpiarNumero(wsGrafTemp.Cells(gFila, 2))
            ElseIf InStr(gTxt, "MINIMA") > 0 Or InStr(gTxt, "MÍNIMA") > 0 Then
                ventaMin = LimpiarNumero(wsGrafTemp.Cells(gFila, 2))
            End If
        Next gFila
    End If
    
    ' ── Crear hoja del informe ──
    Dim wsInforme As Worksheet
    Dim nombreHoja As String
    nombreHoja = "INFORME " & mesNombre
    
    ' Eliminar hoja anterior si existe
    Application.DisplayAlerts = False
    On Error Resume Next
    wb.Worksheets(nombreHoja).Delete
    On Error GoTo 0
    Application.DisplayAlerts = True
    
    Set wsInforme = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.Count))
    wsInforme.Name = nombreHoja
    
    ' ── Configurar página ──
    With wsInforme.PageSetup
        .Orientation = xlPortrait
        .PaperSize = xlPaperLetter
        .LeftMargin = Application.InchesToPoints(0.75)
        .RightMargin = Application.InchesToPoints(0.75)
        .TopMargin = Application.InchesToPoints(0.75)
        .BottomMargin = Application.InchesToPoints(0.75)
        .CenterHorizontally = True
        .FitToPagesWide = 1
        .FitToPagesTall = False
        .PrintArea = "$A$1:$G$200"
    End With
    
    ' ── Anchos de columna ──
    wsInforme.Columns("A").ColumnWidth = 16
    wsInforme.Columns("B").ColumnWidth = 14
    wsInforme.Columns("C").ColumnWidth = 14
    wsInforme.Columns("D").ColumnWidth = 14
    wsInforme.Columns("E").ColumnWidth = 14
    wsInforme.Columns("F").ColumnWidth = 14
    wsInforme.Columns("G").ColumnWidth = 14
    
    ' ────────────────────────────────────────────────
    ' SECCIÓN 1: ENCABEZADO
    ' ────────────────────────────────────────────────
    Dim fila As Long
    fila = 1
    
    ' Título principal
    With wsInforme.Range("A" & fila & ":G" & fila)
        .Merge
        .Value = tiendaNombre
        .Font.Name = "Arial"
        .Font.Size = 20
        .Font.Bold = True
        .Font.Color = COLOR_AZUL
        .HorizontalAlignment = xlCenter
        .RowHeight = 32
    End With
    fila = fila + 1
    
    With wsInforme.Range("A" & fila & ":G" & fila)
        .Merge
        .Value = "CORTE DE CAJA"
        .Font.Name = "Arial"
        .Font.Size = 16
        .Font.Bold = True
        .Font.Color = COLOR_AZUL
        .HorizontalAlignment = xlCenter
        .RowHeight = 26
    End With
    fila = fila + 1
    
    With wsInforme.Range("A" & fila & ":G" & fila)
        .Merge
        .Value = "MES DE " & mesNombre
        .Font.Name = "Arial"
        .Font.Size = 14
        .Font.Bold = True
        .Font.Color = COLOR_AZUL
        .HorizontalAlignment = xlCenter
        .Interior.Color = COLOR_AZUL_CLARO
        .RowHeight = 24
    End With
    fila = fila + 1
    
    ' Línea separadora
    wsInforme.Range("A" & fila & ":G" & fila).RowHeight = 6
    wsInforme.Range("A" & fila & ":G" & fila).Interior.Color = COLOR_AZUL
    fila = fila + 1
    
    ' ────────────────────────────────────────────────
    ' SECCIÓN 2: RESUMEN GENERAL DEL MES
    ' ────────────────────────────────────────────────
    fila = fila + 1
    
    Call EscribirTituloSeccion(wsInforme, fila, "RESUMEN GENERAL DEL MES", COLOR_AZUL)
    fila = fila + 2
    
    ' Fila de etiquetas
    Call EscribirCeldaHeader(wsInforme, fila, 1, "INGRESOS", COLOR_AZUL)
    Call EscribirCeldaHeader(wsInforme, fila, 2, "EGRESOS", COLOR_AZUL)
    Call EscribirCeldaHeader(wsInforme, fila, 3, "TOTAL", COLOR_AZUL)
    Call EscribirCeldaHeader(wsInforme, fila, 4, "DECLARADO", COLOR_AZUL)
    Call EscribirCeldaHeader(wsInforme, fila, 5, "VENTAS", COLOR_AZUL)
    Call EscribirCeldaHeader(wsInforme, fila, 6, "COBRANZA", COLOR_AZUL)
    Call EscribirCeldaHeader(wsInforme, fila, 7, "DIFERENCIA", COLOR_AZUL)
    fila = fila + 1
    
    ' Fila de valores
    Call EscribirCeldaMonto(wsInforme, fila, 1, totalIngresos, False)
    Call EscribirCeldaMonto(wsInforme, fila, 2, totalEgresos, False)
    Call EscribirCeldaMonto(wsInforme, fila, 3, totalIngresos - totalEgresos, False)
    Call EscribirCeldaMonto(wsInforme, fila, 4, totalDeclarado, False)
    Call EscribirCeldaMonto(wsInforme, fila, 5, totalVentas, False)
    Call EscribirCeldaMonto(wsInforme, fila, 6, totalCobranza, False)
    Call EscribirCeldaMonto(wsInforme, fila, 7, totalDiferencia, True)
    fila = fila + 1
    
    ' Crédito y Venta+Crédito en segunda fila
    fila = fila + 1
    Call EscribirCeldaHeader(wsInforme, fila, 1, "VENTAS A CRÉDITO", COLOR_AZUL)
    Call EscribirCeldaMonto(wsInforme, fila, 2, totalCredito, False)
    fila = fila + 1
    
    ' ────────────────────────────────────────────────
    ' SECCIÓN 3: DÍAS DE LA SEMANA — DETALLE
    ' ────────────────────────────────────────────────
    fila = fila + 1
    Call EscribirTituloSeccion(wsInforme, fila, "DETALLE POR DÍA DE LA SEMANA", COLOR_VERDE)
    fila = fila + 2
    
    ' Leer y escribir detalle de cada día
    If wsDiasName <> "" Then
        Dim wsDiasDet As Worksheet
        Set wsDiasDet = wb.Worksheets(wsDiasName)
        Dim maxDias As Long
        maxDias = wsDiasDet.Cells(wsDiasDet.Rows.Count, 1).End(xlUp).Row
        
        Dim diaActual As String
        diaActual = ""
        Dim diaHeaderFila As Long
        diaHeaderFila = 0
        
        Call EscribirCeldaHeader(wsInforme, fila, 1, "FECHA", COLOR_VERDE)
        Call EscribirCeldaHeader(wsInforme, fila, 2, "DÍA", COLOR_VERDE)
        Call EscribirCeldaHeader(wsInforme, fila, 3, "INGRESOS", COLOR_VERDE)
        Call EscribirCeldaHeader(wsInforme, fila, 4, "EGRESOS", COLOR_VERDE)
        Call EscribirCeldaHeader(wsInforme, fila, 5, "TOTAL", COLOR_VERDE)
        Call EscribirCeldaHeader(wsInforme, fila, 6, "DECLARADO", COLOR_VERDE)
        Call EscribirCeldaHeader(wsInforme, fila, 7, "DIFERENCIA", COLOR_VERDE)
        fila = fila + 1
        
        Dim colorAlterna As Boolean
        colorAlterna = False
        
        Dim k As Long
        For k = 2 To maxDias
            Dim cFecha As String
            cFecha = Trim(CStr(wsDiasDet.Cells(k, 1).Value))
            Dim cDia As String
            cDia = Trim(CStr(wsDiasDet.Cells(k, 2).Value))
            
            If IsDate(cFecha) And cDia <> "" And cDia <> "DIA" And cDia <> "DIAS" Then
                Dim bgColor As Long
                If colorAlterna Then
                    bgColor = COLOR_GRIS
                Else
                    bgColor = RGB(255, 255, 255)
                End If
                colorAlterna = Not colorAlterna
                
                Dim ingRow As Double
                Dim egrRow As Double
                Dim totRow As Double
                Dim declRow As Double
                Dim difRow As Double
                
                ingRow = LimpiarNumero(wsDiasDet.Cells(k, 4))
                egrRow = LimpiarNumero(wsDiasDet.Cells(k, 5))
                totRow = LimpiarNumero(wsDiasDet.Cells(k, 6))
                declRow = LimpiarNumero(wsDiasDet.Cells(k, 7))
                difRow = LimpiarNumero(wsDiasDet.Cells(k, 8))
                
                Call EscribirCeldaDato(wsInforme, fila, 1, cFecha, bgColor)
                Call EscribirCeldaDato(wsInforme, fila, 2, cDia, bgColor)
                Call EscribirCeldaMontoColor(wsInforme, fila, 3, ingRow, False, bgColor)
                Call EscribirCeldaMontoColor(wsInforme, fila, 4, egrRow, False, bgColor)
                Call EscribirCeldaMontoColor(wsInforme, fila, 5, totRow, False, bgColor)
                Call EscribirCeldaMontoColor(wsInforme, fila, 6, declRow, False, bgColor)
                Call EscribirCeldaMontoColor(wsInforme, fila, 7, difRow, True, bgColor)
                fila = fila + 1
            End If
        Next k
    End If
    
    ' ────────────────────────────────────────────────
    ' SECCIÓN 4: TOTALES POR DÍA DE LA SEMANA
    ' ────────────────────────────────────────────────
    fila = fila + 1
    Call EscribirTituloSeccion(wsInforme, fila, "TOTALES POR DÍA DE LA SEMANA", COLOR_AZUL)
    fila = fila + 2
    
    Call EscribirCeldaHeader(wsInforme, fila, 1, "DÍA", COLOR_AZUL)
    Call EscribirCeldaHeader(wsInforme, fila, 2, "INGRESOS", COLOR_AZUL)
    Call EscribirCeldaHeader(wsInforme, fila, 3, "DECLARADO", COLOR_AZUL)
    Call EscribirCeldaHeader(wsInforme, fila, 4, "DIFERENCIA", COLOR_AZUL)
    Call EscribirCeldaHeader(wsInforme, fila, 5, "% DEL MES", COLOR_AZUL)
    fila = fila + 1
    
    Dim diasData(5, 2) As Double
    diasData(0, 0) = ingLunes
    diasData(0, 1) = declLunes
    diasData(0, 2) = difLunes
    diasData(1, 0) = ingMartes
    diasData(1, 1) = declMartes
    diasData(1, 2) = difMartes
    diasData(2, 0) = ingMierc
    diasData(2, 1) = declMierc
    diasData(2, 2) = difMierc
    diasData(3, 0) = ingJueves
    diasData(3, 1) = declJueves
    diasData(3, 2) = difJueves
    diasData(4, 0) = ingViernes
    diasData(4, 1) = declViernes
    diasData(4, 2) = difViernes
    diasData(5, 0) = ingSabado
    diasData(5, 1) = declSabado
    diasData(5, 2) = difSabado
    
    Dim d As Integer
    For d = 0 To 5
        Dim pct As Double
        If totalIngresos > 0 Then
            pct = diasData(d, 0) / totalIngresos * 100
        Else
            pct = 0
        End If
        
        Dim bgD As Long
        If d Mod 2 = 0 Then bgD = COLOR_GRIS Else bgD = RGB(255, 255, 255)
        
        Call EscribirCeldaDato(wsInforme, fila, 1, diasNombres(d), bgD)
        Call EscribirCeldaMontoColor(wsInforme, fila, 2, diasData(d, 0), False, bgD)
        Call EscribirCeldaMontoColor(wsInforme, fila, 3, diasData(d, 1), False, bgD)
        Call EscribirCeldaMontoColor(wsInforme, fila, 4, diasData(d, 2), True, bgD)
        
        ' Porcentaje
        With wsInforme.Cells(fila, 5)
            .Value = pct / 100
            .NumberFormat = "0.0%"
            .Font.Name = "Arial"
            .Font.Size = 10
            .HorizontalAlignment = xlCenter
            .Interior.Color = bgD
            .Borders(xlEdgeLeft).LineStyle = xlContinuous
            .Borders(xlEdgeRight).LineStyle = xlContinuous
            .Borders(xlEdgeBottom).LineStyle = xlContinuous
            .Borders(xlEdgeBottom).Color = RGB(200, 200, 200)
        End With
        fila = fila + 1
    Next d
    
    ' ────────────────────────────────────────────────
    ' SECCIÓN 5: TABLA COMPARATIVA (Venta Max/Min/Prom)
    ' ────────────────────────────────────────────────
    fila = fila + 1
    Call EscribirTituloSeccion(wsInforme, fila, "ESTADÍSTICAS DEL MES", COLOR_AZUL)
    fila = fila + 2
    
    Call EscribirCeldaHeader(wsInforme, fila, 1, "ESTADÍSTICA", COLOR_AZUL)
    Call EscribirCeldaHeader(wsInforme, fila, 2, "VALOR", COLOR_AZUL)
    fila = fila + 1
    
    If ventaProm > 0 Then
        Call EscribirCeldaDato(wsInforme, fila, 1, "PROMEDIO SEMANAL", COLOR_GRIS)
        Call EscribirCeldaMontoColor(wsInforme, fila, 2, ventaProm, False, COLOR_GRIS)
        fila = fila + 1
        Call EscribirCeldaDato(wsInforme, fila, 1, "VENTA MÁXIMA", RGB(255, 255, 255))
        Call EscribirCeldaMontoColor(wsInforme, fila, 2, ventaMax, False, RGB(255, 255, 255))
        fila = fila + 1
        Call EscribirCeldaDato(wsInforme, fila, 1, "VENTA MÍNIMA", COLOR_GRIS)
        Call EscribirCeldaMontoColor(wsInforme, fila, 2, ventaMin, False, COLOR_GRIS)
        fila = fila + 1
    Else
        ' Calcular desde los datos leídos
        Dim sumaD As Double, contD As Integer
        sumaD = 0
        contD = 0
        Dim maxD As Double, minD As Double
        maxD = 0
        minD = 9999999999#
        Dim arrD(5) As Double
        arrD(0) = declLunes: arrD(1) = declMartes: arrD(2) = declMierc
        arrD(3) = declJueves: arrD(4) = declViernes: arrD(5) = declSabado
        Dim ad As Integer
        For ad = 0 To 5
            If arrD(ad) > 0 Then
                sumaD = sumaD + arrD(ad)
                contD = contD + 1
                If arrD(ad) > maxD Then maxD = arrD(ad)
                If arrD(ad) < minD Then minD = arrD(ad)
            End If
        Next ad
        If contD > 0 Then
            Call EscribirCeldaDato(wsInforme, fila, 1, "PROMEDIO SEMANAL", COLOR_GRIS)
            Call EscribirCeldaMontoColor(wsInforme, fila, 2, sumaD / contD, False, COLOR_GRIS)
            fila = fila + 1
            Call EscribirCeldaDato(wsInforme, fila, 1, "VENTA MÁXIMA (DÍA)", RGB(255, 255, 255))
            Call EscribirCeldaMontoColor(wsInforme, fila, 2, maxD, False, RGB(255, 255, 255))
            fila = fila + 1
            Call EscribirCeldaDato(wsInforme, fila, 1, "VENTA MÍNIMA (DÍA)", COLOR_GRIS)
            Call EscribirCeldaMontoColor(wsInforme, fila, 2, minD, False, COLOR_GRIS)
            fila = fila + 1
        End If
    End If
    
    ' ────────────────────────────────────────────────
    ' SECCIÓN 6: OBSERVACIONES
    ' ────────────────────────────────────────────────
    fila = fila + 1
    Call EscribirTituloSeccion(wsInforme, fila, "OBSERVACIONES DEL MES", RGB(100, 100, 100))
    fila = fila + 2
    
    With wsInforme.Range("A" & fila & ":G" & (fila + 4))
        .Merge
        .Value = "Escribir observaciones aquí..."
        .Font.Name = "Arial"
        .Font.Size = 10
        .Font.Color = RGB(150, 150, 150)
        .Font.Italic = True
        .VerticalAlignment = xlTop
        .WrapText = True
        .Interior.Color = RGB(252, 252, 252)
        .Borders(xlEdgeLeft).LineStyle = xlContinuous
        .Borders(xlEdgeRight).LineStyle = xlContinuous
        .Borders(xlEdgeTop).LineStyle = xlContinuous
        .Borders(xlEdgeBottom).LineStyle = xlContinuous
        .Borders(xlEdgeLeft).Color = RGB(200, 200, 200)
        .Borders(xlEdgeRight).Color = RGB(200, 200, 200)
        .Borders(xlEdgeTop).Color = RGB(200, 200, 200)
        .Borders(xlEdgeBottom).Color = RGB(200, 200, 200)
        .RowHeight = 18
    End With
    fila = fila + 6
    
    ' ── Pie de página ──
    fila = fila + 1
    wsInforme.Range("A" & fila & ":G" & fila).Interior.Color = COLOR_AZUL
    wsInforme.Range("A" & fila & ":G" & fila).RowHeight = 4
    fila = fila + 1
    With wsInforme.Range("A" & fila & ":G" & fila)
        .Merge
        .Value = "Generado automáticamente — " & Format(Now(), "DD/MM/YYYY HH:MM")
        .Font.Name = "Arial"
        .Font.Size = 8
        .Font.Color = RGB(150, 150, 150)
        .Font.Italic = True
        .HorizontalAlignment = xlRight
    End With
    
    ' ── Activar la hoja del informe ──
    wsInforme.Activate
    wsInforme.Range("A1").Select
    
    MsgBox "✅ Informe generado correctamente." & Chr(13) & Chr(13) & _
           "Hoja: """ & nombreHoja & """" & Chr(13) & _
           "Tienda: " & tiendaNombre & Chr(13) & _
           "Mes: " & mesNombre & Chr(13) & Chr(13) & _
           "Recuerda agregar las observaciones del mes.", _
           vbInformation, "Informe Listo"
End Sub

' ─────────────────────────────────────────────────────────
' FUNCIONES AUXILIARES
' ─────────────────────────────────────────────────────────

Function LimpiarNumero(cel As Range) As Double
    Dim v As String
    v = Trim(CStr(cel.Value))
    v = Replace(v, "$", "")
    v = Replace(v, ",", "")
    v = Trim(v)
    If v = "" Or v = "0" Or IsNull(v) Then
        LimpiarNumero = 0
    ElseIf IsNumeric(v) Then
        LimpiarNumero = CDbl(v)
    Else
        LimpiarNumero = 0
    End If
End Function

Function DetectarMes(texto As String) As String
    Dim meses(11) As String
    meses(0) = "ENERO": meses(1) = "FEBRERO": meses(2) = "MARZO"
    meses(3) = "ABRIL": meses(4) = "MAYO": meses(5) = "JUNIO"
    meses(6) = "JULIO": meses(7) = "AGOSTO": meses(8) = "SEPTIEMBRE"
    meses(9) = "OCTUBRE": meses(10) = "NOVIEMBRE": meses(11) = "DICIEMBRE"
    
    Dim m As Integer
    For m = 0 To 11
        If InStr(texto, meses(m)) > 0 Then
            DetectarMes = meses(m) & " " & DetectarAnio(texto)
            Exit Function
        End If
    Next m
    DetectarMes = Format(Now(), "MMMM YYYY")
End Function

Function DetectarAnio(texto As String) As String
    Dim anio As Integer
    For anio = 2020 To 2035
        If InStr(texto, CStr(anio)) > 0 Then
            DetectarAnio = CStr(anio)
            Exit Function
        End If
    Next anio
    DetectarAnio = CStr(Year(Now()))
End Function

Function DetectarTienda(texto As String) As String
    If InStr(texto, "APATZINGAN") > 0 Or InStr(texto, "APATZINGÁN") > 0 Then
        DetectarTienda = "APATZINGÁN"
    ElseIf InStr(texto, "NUEVA_ITALIA") > 0 Or InStr(texto, "NUEVA ITALIA") > 0 Then
        DetectarTienda = "NUEVA ITALIA"
    ElseIf InStr(texto, "SAN_SIMON") > 0 Or InStr(texto, "SAN SIMON") > 0 Then
        DetectarTienda = "SAN SIMÓN"
    Else
        DetectarTienda = "TIENDA"
    End If
End Function

Sub EscribirTituloSeccion(ws As Worksheet, fila As Long, texto As String, color As Long)
    With ws.Range("A" & fila & ":G" & fila)
        .Merge
        .Value = texto
        .Font.Name = "Arial"
        .Font.Size = 12
        .Font.Bold = True
        .Font.Color = RGB(255, 255, 255)
        .HorizontalAlignment = xlLeft
        .Interior.Color = color
        .IndentLevel = 1
        .RowHeight = 22
    End With
End Sub

Sub EscribirCeldaHeader(ws As Worksheet, fila As Long, col As Integer, texto As String, color As Long)
    With ws.Cells(fila, col)
        .Value = texto
        .Font.Name = "Arial"
        .Font.Size = 9
        .Font.Bold = True
        .Font.Color = RGB(255, 255, 255)
        .HorizontalAlignment = xlCenter
        .Interior.Color = color
        .RowHeight = 18
        .Borders(xlEdgeLeft).LineStyle = xlContinuous
        .Borders(xlEdgeRight).LineStyle = xlContinuous
        .Borders(xlEdgeBottom).LineStyle = xlContinuous
        .Borders(xlEdgeLeft).Color = RGB(200, 200, 200)
        .Borders(xlEdgeRight).Color = RGB(200, 200, 200)
        .Borders(xlEdgeBottom).Color = RGB(200, 200, 200)
    End With
End Sub

Sub EscribirCeldaMonto(ws As Worksheet, fila As Long, col As Integer, valor As Double, esDiferencia As Boolean)
    Call EscribirCeldaMontoColor(ws, fila, col, valor, esDiferencia, RGB(255, 255, 255))
End Sub

Sub EscribirCeldaMontoColor(ws As Worksheet, fila As Long, col As Integer, valor As Double, esDiferencia As Boolean, bgColor As Long)
    With ws.Cells(fila, col)
        .Value = valor
        .NumberFormat = "$#,##0.00"
        .Font.Name = "Arial"
        .Font.Size = 10
        .HorizontalAlignment = xlRight
        .Interior.Color = bgColor
        .RowHeight = 18
        If esDiferencia Then
            If valor < -1 Then
                .Font.Color = RGB(180, 0, 0)
                .Font.Bold = True
            ElseIf valor > 1 Then
                .Font.Color = RGB(26, 107, 58)
            Else
                .Font.Color = RGB(100, 100, 100)
            End If
        Else
            .Font.Color = RGB(30, 30, 30)
        End If
        .Borders(xlEdgeLeft).LineStyle = xlContinuous
        .Borders(xlEdgeRight).LineStyle = xlContinuous
        .Borders(xlEdgeBottom).LineStyle = xlContinuous
        .Borders(xlEdgeLeft).Color = RGB(200, 200, 200)
        .Borders(xlEdgeRight).Color = RGB(200, 200, 200)
        .Borders(xlEdgeBottom).Color = RGB(200, 200, 200)
    End With
End Sub

Sub EscribirCeldaDato(ws As Worksheet, fila As Long, col As Integer, texto As String, bgColor As Long)
    With ws.Cells(fila, col)
        .Value = texto
        .Font.Name = "Arial"
        .Font.Size = 10
        .HorizontalAlignment = xlLeft
        .Interior.Color = bgColor
        .RowHeight = 18
        .IndentLevel = 1
        .Borders(xlEdgeLeft).LineStyle = xlContinuous
        .Borders(xlEdgeRight).LineStyle = xlContinuous
        .Borders(xlEdgeBottom).LineStyle = xlContinuous
        .Borders(xlEdgeLeft).Color = RGB(200, 200, 200)
        .Borders(xlEdgeRight).Color = RGB(200, 200, 200)
        .Borders(xlEdgeBottom).Color = RGB(200, 200, 200)
    End With
End Sub

Sub AgregarBotonGenerarInforme()
    ' ── Agrega el botón "Generar Informe" a la hoja activa ──
    Dim ws As Worksheet
    Set ws = ActiveSheet
    
    Dim btn As Object
    Set btn = ws.Buttons.Add(10, 10, 160, 30)
    btn.Caption = "📄 GENERAR INFORME"
    btn.OnAction = "GenerarInformeMensual"
    btn.Characters.Font.Name = "Arial"
    btn.Characters.Font.Size = 11
    btn.Characters.Font.Bold = True
    
    MsgBox "Botón agregado a la hoja '" & ws.Name & "'." & Chr(13) & _
           "Haz clic en él para generar el informe.", vbInformation, "Botón Creado"
End Sub
